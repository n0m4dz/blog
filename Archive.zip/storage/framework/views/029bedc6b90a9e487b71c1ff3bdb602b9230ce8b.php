<ul>
	<li class=" <?php echo e(Request::is('list') ? 'active' : ''); ?>">
		<a href="<?php echo e(URL::route('blog.list')); ?>"> Мэдээ </a>
	</li>

	<li class=" <?php echo e(Request::segment(1) === 'blog' ? 'active' : ''); ?> ">
		<a href="<?php echo e(url('blog')); ?>"> Мэдээ оруулах </a>
	</li>
</ul>