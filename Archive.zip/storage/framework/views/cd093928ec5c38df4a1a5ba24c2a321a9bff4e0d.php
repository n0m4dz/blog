<!DOCTYPE html>
<html>
<head>
	<title><?php echo e(isset($pageTitle) ? $pageTitle : 'Blog web'); ?></title>

	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="/css/vendor.css">
		<link rel="stylesheet" type="text/css" href="<?php echo e(elixir('css/style.css')); ?>">

	<!-- tuhain huudasnii stylesheet -->
	<?php echo $__env->yieldContent('style'); ?>
	<style type="text/css">
		.active a{
			font-weight:bold;
			color: #f92343;
		}
	</style>
	
</head>
<body>
	<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<hr>

	<?php echo $__env->yieldContent('content2'); ?>
		


	<script type="text/javascript" src="<?php echo e(URL::asset('js/vendor.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(elixir('js/blog.js')); ?>"></script>		
	<!-- tuhain huudasnii script -->
	<?php echo $__env->yieldContent('script'); ?>
</body>
</html>