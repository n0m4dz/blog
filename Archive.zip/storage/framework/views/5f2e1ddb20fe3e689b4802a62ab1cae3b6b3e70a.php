<?php $__env->startSection('style'); ?>
	<style type="text/css">
	body{
		background: #f6f6f6;
		color:#464646;
	}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<form action="/blog/search" method="get" class="search-form horizontal-form">
		<div class="form-group">
			<select name="user" class="form-control">
				<option value="">...</option>
				<?php foreach($users as $user): ?>
					<option value="<?php echo e($user->id); ?>" 
						<?php if( $user->id == Request::get('user')): ?> selected <?php endif; ?>
						> 
						<?php echo e($user->email); ?> 
					</option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="form-group">
			<input type="text" name="search" class="form-control" 
					value="<?php echo e(Request::get('search')); ?>" />
		</div>
		<div class="form-group">
			<button type="submit" class="btn btn-success"> Хайх </button>
		</div>
	</form>

	<h4>
		<?php if(Session::has('msg')): ?>
			<?php echo e(Session::get('msg')); ?>

		<?php endif; ?>
	</h4>

	<ul>
	<?php foreach($mydata as $md): ?>
		<li>
			<strong><?php echo e($md->title); ?></strong>
			<br/>
			<?php echo e($md->content); ?>

			<hr/>
		</li>
	<?php endforeach; ?>
	</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>