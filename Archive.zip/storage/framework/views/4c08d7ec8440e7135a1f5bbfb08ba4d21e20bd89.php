<?php $helper = app('Helper\MyHelper'); ?>



<?php $__env->startSection('style'); ?>
	<style type="text/css">
	body{
		background: #dddddd;
	}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>	

	<h3><?php echo e(Auth::user()->name); ?></h3>

	<form id="postFrm" action="<?php echo e(URL::route('ORM::store')); ?>" method="post">
		<?php echo csrf_field(); ?>

		<input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" /> <br>

		<textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea> <br>

		<input type="submit" value="submit" class="btn btn-success" />
			
			<?php if(isset($errors) && count($errors) > 0): ?>
			<hr>
				<?php foreach($errors->all() as $e): ?>
					<?php echo e(dump($e)); ?>

				<?php endforeach; ?>
			<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		
		$(function(){

			$('#postFrm').submit(function(e){
				e.preventDefault(0);

				var data = $(this).serialize();
				//console.log(data);

				$.ajax({
					type: 'POST',
					url: '/orm/store',
					data: data,
					success: function(resp){
						console.log(resp);
						if(resp.status){
							alert('successfully');
						}
					},
					error: function(resp){

					}
				});
			})

		})

	</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>