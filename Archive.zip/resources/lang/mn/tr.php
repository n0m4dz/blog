<?php
	return [
		'apple' => 'Alim'
	]
?>