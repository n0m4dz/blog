<?php
	return [
		'apple' => 'Apple'
	]
?>